Hi, this is a tutorial on how to use Reptilia External for Counter-Strike 2.


-- INITIAL SETUP --
1. Make sure the folder the bootstrapper is excluded from your antivirus (Create an antivirus exclusion)
2. Run the bootstrapper and wait until it is finished.

The bootstrapper is the updater, to make sure you are always up to date, always run the bootstrapper before running the cheat

-- DRIVER NOTICE --

whenever the driver is loaded, it will get detected on most powerful anticheats (e.g, BE, UAC, EAC, Vanguard) and it will get you banned.
To unload the driver, simply restart your computer.


-- SETTING UP THE DRIVER --


Open up core isolation (Windows button and search core isolation). Disable everything in it.

-- FIX VULNERABLE DRIVER BLOCKLIST STEP (If the Microsoft Vulnerable Driver Blocklist is greyed out, go into the "External" folder, then "Driver" folder, and run the "FixVulnerableriverBlocklist" file)

Once done, restart your computer.

if you did the FIX VULNERABLE DRIVER BLOCKLIST STEP, go back into core isolation and disable the "Microsoft Vulnerable Driver Blocklist" (if it requires you to restart your computer, restart your computer)

Once everything in the "Core Isolation" page is disabled, proceed to the next step

-- LOADING THE DRIVER -- 

go into the "External" folder, then "Driver" folder, and drag the "Driver" file onto the "Mapper" file. If something black appears and then disappears automatically, it means you did it correctly.

-- STARTING THE CHEAT --

go into the "External" folder, and run the "External" file